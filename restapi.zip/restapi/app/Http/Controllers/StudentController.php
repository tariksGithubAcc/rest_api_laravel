<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use Validator;

class StudentController extends Controller
{
    public function index()
    {
        $students = Student::all();

        $data = [
            'status' => 200,
            'students' => $students
        ];

        return response()->json($data, 200);
    }

    public function upload(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required' // Added phone validation as it is used in your code
        ]);

        if ($validator->fails()) {
            $data = [
                'status' => 422,
                'errors' => $validator->errors()
            ];
            return response()->json($data, 422);
        } else {
            $student = new Student;
            $student->name = $request->name;
            $student->email = $request->email;
            $student->phone = $request->phone;
            $student->save();

            $data = [
                'status' => 200,
                'message' => 'Data uploaded successfully',
                'student' => $student
            ];
            return response()->json($data, 200);
        }
    }

    public function edit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required' // Ensure phone is included if it's being updated
        ]);

        if ($validator->fails()) {
            $data = [
                'status' => 422,
                'errors' => $validator->errors()
            ];
            return response()->json($data, 422);
        } else {
            // Find the student by ID
            $student = Student::find($id);

            if (!$student) {
                $data = [
                    'status' => 404,
                    'message' => 'Student not found'
                ];
                return response()->json($data, 404);
            }

            // Update the student's details
            $student->name = $request->name;
            $student->email = $request->email;
            $student->phone = $request->phone;
            $student->save();

            $data = [
                'status' => 200,
                'message' => 'Data updated successfully',
                'student' => $student
            ];
            return response()->json($data, 200);
        }
    }
}
